#These information comes from Twitter API
#Create a Twitter Account and Get These Information from apps.twitter.com

consumer_key = 'qUqABnLA0lPyoLNFxV9OF5VFC'
consumer_secret = 'OZJmXthjf5APTlvmdHUyGBvW6IBj3BqQGax1ZAwLqZFxzbJsba'
access_token = '15257539-duK7OfwVvTih6r9bXsJQsB8fmEpMN7fFDzbIMhuGu'
access_secret = '3dv7Nxnb5aqm6yOSNM9f9UQ6CePb6TJDwtIECf2zpdBKP'
